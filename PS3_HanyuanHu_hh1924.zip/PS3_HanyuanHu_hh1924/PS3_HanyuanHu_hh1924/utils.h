#pragma once

template <typename T>
inline T MAX(T x1, T x2)
{
	if (x1 > x2) return x1;
	else return x2;
};